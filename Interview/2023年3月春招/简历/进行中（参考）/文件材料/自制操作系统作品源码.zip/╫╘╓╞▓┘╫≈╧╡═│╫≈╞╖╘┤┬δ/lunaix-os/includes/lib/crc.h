#ifndef __LUNAIX_CRC_H
#define __LUNAIX_CRC_H
unsigned int
crc32b(unsigned char* data, unsigned int size);

#endif /* __LUNAIX_CRC_H */
