void
my_dummy()
{
    while (1) {
        asm("hlt");
    }
}
